from django import forms
from .models import Quiz, Question, AnswerOption, StudentAnswer

class QuizForm(forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ['course', 'quiz_title', 'quiz_description', 'total_marks']
        widgets = {
            'course': forms.Select(),
        }

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['question_text', 'question_type', 'points']

class AnswerOptionForm(forms.ModelForm):
    class Meta:
        model = AnswerOption
        fields = ['option_text', 'is_correct']


class QuizAnswerForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.questions = kwargs.pop('questions')  # List of questions
        super(QuizAnswerForm, self).__init__(*args, **kwargs)
        
        for question in self.questions:
            if question.question_type == 'MCQ':
                # Create multiple-choice field
                choices = [(option.id, option.option_text) for option in question.answer_options.all()]
                self.fields[f'question_{question.id}'] = forms.ChoiceField(
                    label=question.question_text,
                    widget=forms.RadioSelect,
                    choices=[(option.id, option.option_text) for option in question.answer_options.all()],
                    required=True
                )
            elif question.question_type == 'TF':
                # Create true/false field
                self.fields[f'question_{question.id}'] = forms.ChoiceField(
                    label=question.question_text,
                    widget=forms.RadioSelect,
                    choices=[(True, 'True'), (False, 'False')]
                )